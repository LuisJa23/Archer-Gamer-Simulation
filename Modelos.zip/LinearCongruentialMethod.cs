using System;
using System.Collections.Generic;

public class LinearCongruentialMethod
{
    // Lista para almacenar los valores de Ri
    private List<double> riValues;

    private int xo; // Semilla inicial
    private int k;  // Multiplicador base
    private int c;  // Incremento
    private long g;  // Parámetro del módulo
    private int iterations; // Número de iteraciones

    // Constructor
    public LinearCongruentialMethod(int xo, int k, int c, long g, int iterations)
    {
        this.riValues = new List<double>();
        this.xo = xo;
        this.k = k;
        this.c = c;
        this.g = g;
        this.iterations = iterations;
        FillRiValues();
    }

    // Método para generar el valor 'a'
    private int GenerateAValue()
    {
        return 1 + (2 * k);
    }

    // Método para determinar la cantidad de números posibles (módulo)
    private int DetermineNumberAmount()
    {
        return (int)Math.Pow(2, g);
    }

    // Método para calcular y almacenar los valores Ri
    public void FillRiValues()
    {
        int a = GenerateAValue();
        int amount = DetermineNumberAmount();
        double xi = xo; // Comenzamos con la semilla

        for (int i = 0; i < iterations; i++)
        {
            xi = ((a * xi) + c) % amount; // Calculamos el valor Xi
            double riValue = xi / (amount - 1); // Calculamos el valor Ri

            // Solo almacenamos Ri si no es 0 ni 1
            if (riValue != 0 && riValue != 1)
            {
                riValues.Add(Math.Round(riValue, 5)); // Almacenamos Ri
            }
        }
    }

    // Método para obtener el conjunto de valores Ri
    public List<double> GetRiValues()
    {
        return riValues;
    }
}


public class RandomNumberValidator
    {
        // Propiedad para almacenar los números generados
        private List<double> numbers;

        // Constructor que toma una lista de números
        public RandomNumberValidator(List<double> inputNumbers)
        {
            this.numbers = inputNumbers;
    }

        // Función que valida si los números pasan todas las pruebas
        public List<double> GetValidNumbers()
        {
            // Creamos instancias de las pruebas
            AverageTest at = new AverageTest(numbers.ToArray());
            ChiSquaredTest ct = new ChiSquaredTest(numbers);
            KsTest kt = new KsTest();
            VarianceTest vt = new VarianceTest(numbers.ToArray());
            PokerTest pt = new PokerTest(numbers);

            // Lista para almacenar los números válidos que pasan todas las pruebas
            List<double> validNumbers = new List<double>();

            // Verificamos si todos los test son exitosos
            if (at.CheckTest() && ct.CheckTest() && kt.CheckTest(numbers) && vt.CheckTest() && pt.CheckTest())
            {
                validNumbers = numbers;
            }
           return validNumbers;
        }
    }
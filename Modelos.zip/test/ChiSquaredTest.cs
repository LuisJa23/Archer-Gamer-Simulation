using System;
using System.Collections.Generic;
using System.Linq;

public class ChiSquaredTest
{
    private List<double> riValues;
    private List<double> niValues;
    private List<double> intervalsValues;
    private List<int> frequencyObtained;
    private List<double> expectedFrequency;
    private List<double> chiSquaredValues;

    private int intervalsAmount;
    private double a;
    private double b;

    private double chiSquaredCriticalValue;
    private double chiSquaredSum;

    public ChiSquaredTest(List<double> riValues, int intervalsAmount = 8, double a = 8, double b = 10)
    {
        this.riValues = riValues;
        this.intervalsAmount = intervalsAmount;
        this.a = a;
        this.b = b;
        this.niValues = new List<double>();
        this.intervalsValues = new List<double>();
        this.frequencyObtained = new List<int>();
        this.expectedFrequency = new List<double>();
        this.chiSquaredValues = new List<double>();
    }

    private void FillNiValues()
    {
        foreach (var ri in riValues)
        {
            double value = a + (b - a) * ri;
            niValues.Add(value);
        }
    }

    private void SortNiArray()
    {
        niValues.Sort();
    }

    private double GetMinNiValue()
    {
        return niValues.Min();
    }

    private double GetMaxNiValue()
    {
        return niValues.Max();
    }

    private void FillIntervalsValues()
    {
        double minValue = GetMinNiValue();
        double maxValue = GetMaxNiValue();
        intervalsValues.Add(minValue);

        for (int i = 0; i < intervalsAmount; i++)
        {
            double value = Math.Round(intervalsValues[i] + (maxValue - minValue) / intervalsAmount, 5);
            intervalsValues.Add(value);
        }
    }

    private void FillFrequencies()
    {
        double expectedFreq = Math.Round((double)niValues.Count / intervalsAmount, 2);
        foreach (var interval in intervalsValues.SkipLast(1))
        {
            int counter = niValues.Count(ni => ni >= interval && ni < interval + (GetMaxNiValue() - GetMinNiValue()) / intervalsAmount);
            frequencyObtained.Add(counter);
            expectedFrequency.Add(expectedFreq);
        }
    }

    private void FillChiSquaredValues()
    {
        for (int i = 0; i < frequencyObtained.Count; i++)
        {
            double value = Math.Round(Math.Pow(frequencyObtained[i] - expectedFrequency[i], 2) / expectedFrequency[i], 2);
            chiSquaredValues.Add(value);
        }
    }

    private double ChiSquaredTestValue()
    {
        double marginOfError = 0.05;
        int degreesOfFreedom = intervalsAmount - 1;

        // Valor crítico de Chi-Cuadrado para el nivel de significancia 0.05
        var chiSquared = new MathNet.Numerics.Distributions.ChiSquared(degreesOfFreedom);
        return chiSquared.InverseCumulativeDistribution(1.0 - marginOfError);
    }

    private double CalculateChiSquaredSum()
    {
        return chiSquaredValues.Sum();
    }

    public bool CheckTest()
    {
        FillNiValues();
        SortNiArray();
        FillIntervalsValues();
        FillFrequencies();
        FillChiSquaredValues();

        chiSquaredCriticalValue = ChiSquaredTestValue();
        chiSquaredSum = CalculateChiSquaredSum();

        return chiSquaredSum <= chiSquaredCriticalValue;
    }
}

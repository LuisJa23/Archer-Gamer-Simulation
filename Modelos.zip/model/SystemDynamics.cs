using System;

public class SystemDynamics
{
    private float timeSinceLastAction = 0f; // Tiempo desde la última acción (matar enemigo o similar)
    private const float PENALTY_TIME = 7f; // Tiempo límite sin acción antes de penalizar
    private const float DAMAGE = 1f; // Daño recibido por inactividad

    private float health;
    private bool isImmune = false;

    public SystemDynamics(float initialHealth)
    {
        health = initialHealth;
    }

    public float Health => health;

    public void ResetTimeSinceLastAction()
    {
        timeSinceLastAction = 0f;
    }

    public void ApplyDamage()
    {
        if (!isImmune)
        {
            health -= DAMAGE;
            isImmune = true; // Activar inmunidad temporal
            Console.WriteLine($"¡Daño aplicado! Salud actual: {health}");
        }
    }

    public void Update(float deltaTime)
    {
        // Actualizamos el tiempo desde la última acción
        timeSinceLastAction += deltaTime;

        // Si no ha ocurrido una acción en un tiempo determinado, aplicamos penalización
        if (timeSinceLastAction >= PENALTY_TIME)
        {
            ApplyDamage();
            ResetTimeSinceLastAction();
        }

        // Desactivamos la inmunidad tras un pequeño tiempo
        if (isImmune)
        {
            isImmune = false;
        }
    }

    // Método para mostrar la información importante de la simulación
    public void DisplayStatus()
    {
        Console.WriteLine($"Salud actual: {health}");
        Console.WriteLine($"Tiempo desde la última acción: {timeSinceLastAction}s");
    }
}

public class SystemDynamicsTest
{
    public void RunTest()
    {
        // Inicializamos el sistema de salud con 10 puntos de vida
        var healthSystem = new SystemDynamics(10f);

        Console.WriteLine("Simulando la dinámica del sistema de salud...");

        // Realizamos varias iteraciones para observar el cambio en la salud
        for (int i = 0; i < 10; i++)
        {
            // Simulamos un intervalo de tiempo de 3 segundos en cada iteración
            healthSystem.Update(3f);
            healthSystem.DisplayStatus(); // Mostrar estado después de 3 segundos

            // Simulamos un pequeño retraso para no hacer la simulación demasiado rápida
            System.Threading.Thread.Sleep(500); // 500ms de espera entre iteraciones

            // Si el ciclo alcanza la penalización, reiniciaremos el tiempo
            if (healthSystem.Health <= 0)
            {
                Console.WriteLine("La salud llegó a 0. Reiniciando el sistema...");
                healthSystem = new SystemDynamics(10f); // Reiniciar el sistema
                Console.WriteLine("Sistema reiniciado con 10 puntos de vida.");
            }
        }
    }
}

// public class Program
// {
//     public static void Main(string[] args)
//     {
//         // Crear y ejecutar la prueba del sistema de salud
//         SystemDynamicsTest test = new SystemDynamicsTest();
//         test.RunTest();
//     }
// }

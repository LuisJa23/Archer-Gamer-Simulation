using System;
using System.Collections.Generic;
using System.Threading;

public class ArrivalSystem
{
    private Queue<string> itemQueue = new Queue<string>(); // Cola para almacenar los elementos que llegan
    private float nextArrivalTime; // Tiempo para la siguiente llegada
    private int maxItemsInQueue = 5; // Número máximo de elementos en la cola
    private int previousMilestone = 0; // Marca para controlar umbrales de eventos

    private RandomNumberValidators randomNumberValidator = new RandomNumberValidators(); // Generador de números aleatorios

    // Constructor que inicializa el sistema de llegadas
    public ArrivalSystem(float arrivalRate)
    {
        nextArrivalTime = GetExponentialRandom(arrivalRate);
    }

    // Método que actualiza el sistema de llegadas y genera nuevos elementos si es necesario
    public void Update(int currentMilestone)
    {
        // Verificar si hemos alcanzado un nuevo umbral para modificar el comportamiento
        if (currentMilestone / 100 > previousMilestone)
        {
            previousMilestone = currentMilestone / 100;
            // Aumentar el límite de elementos en cola hasta un máximo
            maxItemsInQueue = Math.Min(10, maxItemsInQueue + 1);
        }

        // Generar nuevos elementos si la cola no ha alcanzado el máximo límite
        if (itemQueue.Count < maxItemsInQueue)
        {
            if (nextArrivalTime <= currentMilestone)
            {
                SpawnItem();
                nextArrivalTime = currentMilestone + GetExponentialRandom(0.05f); // Usando un valor predeterminado para la tasa de llegada
            }
        }
    }

    // Método para obtener un valor aleatorio basado en una distribución exponencial
    private float GetExponentialRandom(float lambda)
    {
        return -MathF.Log((float)(1 - randomNumberValidator.GetNextNumber())) / lambda;
    }

    // Método que simula la llegada de un nuevo item
    private void SpawnItem()
    {
        string newItem = "Item " + DateTime.Now.Second; // Simula un nuevo item con el tiempo actual
        itemQueue.Enqueue(newItem);
        Console.WriteLine($"Nuevo elemento generado: {newItem}");
    }

    // Método para obtener el número actual de elementos en la cola
    public int GetActiveItemCount()
    {
        return itemQueue.Count;
    }

    // Método para obtener los elementos actuales en la cola
    public void DisplayQueueStatus()
    {
        Console.WriteLine($"Elementos activos en la cola: {itemQueue.Count}");
        Console.WriteLine("Contenido de la cola:");
        foreach (var item in itemQueue)
        {
            Console.WriteLine($" - {item}");
        }
    }

    // Método para procesar los elementos de la cola
    public void ProcessQueue()
    {
        if (itemQueue.Count > 0)
        {
            string processedItem = itemQueue.Dequeue();
            Console.WriteLine($"Elemento atendido: {processedItem}");
        }
    }
}

public class ArrivalSystemTest
{
    public void RunTest()
    {
        // Inicializar el sistema de llegadas con una tasa de llegada de 0.05
        ArrivalSystem arrivalSystem = new ArrivalSystem(0.05f);

        int currentMilestone = 0;
        int processedItems = 0;

        // Simulamos el paso del tiempo (por ejemplo, hasta que se generen 5 items)
        while (processedItems < 5)
        {
            // Actualizamos el sistema cada iteración, con el marcador actual de progreso
            currentMilestone++;

            arrivalSystem.Update(currentMilestone);

            // Mostrar estado de la cola cada 10 hitos para observar las llegadas
            if (currentMilestone % 10 == 0)
            {
                Console.WriteLine($"En el hito {currentMilestone}:");
                arrivalSystem.DisplayQueueStatus();
            }

            // Procesar un item si hay elementos en la cola
            if (arrivalSystem.GetActiveItemCount() > 0)
            {
                arrivalSystem.ProcessQueue();
                processedItems++;
            }

            // Simulamos el paso del tiempo con un pequeño retardo para que la consola no imprima demasiado rápido
            Thread.Sleep(200); // 200ms de espera para simular el paso del tiempo
        }

        Console.WriteLine("Simulación completada. Todos los elementos han sido procesados.");
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        // Crear y ejecutar la prueba del sistema de llegadas
        ArrivalSystemTest test = new ArrivalSystemTest();
        test.RunTest();
    }
}

using System;

public class Markov
{
    private RandomNumberValidators randomNumberValidator;

    // Constructor que inicializa el RandomNumberValidators
    public Markov()
    {
        randomNumberValidator = new RandomNumberValidators();
    }

    // Método para obtener el siguiente estado basado en el estado actual
    public int GetNextState(int currentState)
    {
        float random = (float)randomNumberValidator.GetNextRandom();

        // Lógica de transición entre estados basada en el valor del número aleatorio
        if (currentState == 0) // Estado: Sin generar ítem
        {
            if (random < 0.3f) return 2; // 30% a corazón
            else if (random < 0.6f) return 1; // 30% a velocidad
            else return 0; // 40% se queda igual
        }
        else if (currentState == 1) // Estado: Corazón
        {
            if (random < 0.2f) return 1; // 20% a corazón
            else if (random < 0.4f) return 2; // 20% a velocidad
            else return 0; // 60% a sin generar
        }
        else if (currentState == 2) // Estado: Velocidad
        {
            if (random < 0.2f) return 1; // 20% a corazón
            else if (random < 0.4f) return 2; // 20% a velocidad
            else return 0; // 60% a sin generar
        }

        return 0; // Por defecto, no generar nada
    }

    // Método de prueba para verificar el comportamiento de Markov
    public static void TestMarkov()
    {
        Markov markov = new Markov();

        int currentState = 0;
        Console.WriteLine("Estado inicial: " + currentState);

        for (int i = 0; i < 10; i++) // Generar 10 transiciones
        {
            int nextState = markov.GetNextState(currentState);
            Console.WriteLine($"Transición {i + 1}: de {currentState} a {nextState}");
            currentState = nextState; // Actualizar el estado actual
        }
    }
}

// public class MarkovTester
// {
//     public static void Main(string[] args)
//     {
//         // Llamamos al método de prueba de Markov
//         Markov.TestMarkov();
//     }
// }

using System;

public class RandomWalk
{
    private string lastDirection; // Última dirección del movimiento
    public string CurrentDirection { get; private set; } // Dirección actual del movimiento
    private RandomNumberValidators randomNumberValidator; // Usando RandomNumberValidators

    public RandomWalk()
    {
        randomNumberValidator = new RandomNumberValidators(); // Inicializar RandomNumberValidator
        lastDirection = null; // Inicializar sin dirección
    }

    public void SetNewDirection()
    {
        string newDirection;
        do
        {
            double randomValue = randomNumberValidator.GetNextRandom(); // Usar el número aleatorio generado por RandomNumberValidator

            if (randomValue < 0.25)
            {
                newDirection = "Derecha";
            }
            else if (randomValue < 0.5)
            {
                newDirection = "Arriba";
            }
            else if (randomValue < 0.75)
            {
                newDirection = "Izquierda";
            }
            else
            {
                newDirection = "Abajo";
            }
        } while (newDirection == lastDirection); // Evitar repetir la misma dirección

        lastDirection = CurrentDirection; // Actualizar última dirección
        CurrentDirection = newDirection; // Asignar la nueva dirección
    }
}

// Clase para probar RandomWalk
// public class RandomWalkTester
// {
//     public static void Main(string[] args)
//     {
//         RandomWalk randomWalk = new RandomWalk();
//         Console.WriteLine("Simulando RandomWalk:");

//         for (int i = 0; i < 10; i++)
//         {
//             randomWalk.SetNewDirection();
//             Console.WriteLine($"Nueva dirección: {randomWalk.CurrentDirection}");
//         }
//     }
// }
